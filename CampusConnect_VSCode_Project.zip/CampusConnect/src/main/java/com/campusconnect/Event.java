package com.campusconnect;
import jakarta.persistence.*;
@Entity
public class Event {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    private String title;
    private String club;
    private String date;
    private String venue;
    @Column(length=1000) private String description;
    public Event() {}
    public Event(String title, String club, String date, String venue, String description) {
        this.title=title; this.club=club; this.date=date; this.venue=venue; this.description=description;
    }
    public Long getId(){return id;} public String getTitle(){return title;} public String getClub(){return club;}
    public String getDate(){return date;} public String getVenue(){return venue;} public String getDescription(){return description;}
    public void setId(Long id){this.id=id;} public void setTitle(String v){title=v;} public void setClub(String v){club=v;}
    public void setDate(String v){date=v;} public void setVenue(String v){venue=v;} public void setDescription(String v){description=v;}
}
