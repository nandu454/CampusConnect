package com.campusconnect;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
@Controller
public class WebController {
    private final EventRepository events; private final BookingRepository bookings;
    public WebController(EventRepository events, BookingRepository bookings){this.events=events;this.bookings=bookings;}
    @GetMapping("/") public String home(Model model){
        if(events.count()==0){
            events.save(new Event("Tech Spark","Coding Club","2026-11-20","Main Auditorium","A day of coding, ideas and innovation."));
            events.save(new Event("Rhythm Night","Cultural Club","2026-11-24","Open Air Stage","Music, dance and performances."));
            events.save(new Event("Green Campus Drive","Eco Club","2026-11-28","College Garden","Join hands for a cleaner campus."));
        }
        model.addAttribute("events",events.findAll()); return "index";
    }
    @PostMapping("/book") public String book(@RequestParam String studentName,@RequestParam String email,@RequestParam String eventTitle,Model model){
        bookings.save(new Booking(studentName,email,eventTitle)); model.addAttribute("message","Your registration is confirmed!"); model.addAttribute("events",events.findAll()); return "index";
    }
    @GetMapping("/bookings") public String myBookings(@RequestParam(required=false) String email,Model model){
        if(email!=null && !email.isBlank()) model.addAttribute("bookings",bookings.findByEmailIgnoreCase(email));
        model.addAttribute("email",email); return "bookings";
    }
    @GetMapping("/admin") public String admin(Model model){model.addAttribute("events",events.findAll());model.addAttribute("bookings",bookings.findAll());return "admin";}
    @PostMapping("/admin/add") public String add(@RequestParam String title,@RequestParam String club,@RequestParam String date,@RequestParam String venue,@RequestParam String description){
        events.save(new Event(title,club,date,venue,description)); return "redirect:/admin";
    }
    @PostMapping("/admin/delete/{id}") public String delete(@PathVariable Long id){events.deleteById(id);return "redirect:/admin";}
}
