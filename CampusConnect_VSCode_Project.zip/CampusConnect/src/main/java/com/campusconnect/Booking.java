package com.campusconnect;
import jakarta.persistence.*;
@Entity
public class Booking {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    private String studentName; private String email; private String eventTitle;
    public Booking() {}
    public Booking(String studentName,String email,String eventTitle){this.studentName=studentName;this.email=email;this.eventTitle=eventTitle;}
    public Long getId(){return id;} public String getStudentName(){return studentName;} public String getEmail(){return email;} public String getEventTitle(){return eventTitle;}
}
